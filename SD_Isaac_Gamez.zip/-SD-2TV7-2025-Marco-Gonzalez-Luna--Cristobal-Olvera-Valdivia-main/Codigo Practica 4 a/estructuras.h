struct operadores{
	
	float numA;
	float numB;
};